const Footer = () => (
  <footer className="bg-black text-gray-600 text-center py-10 text-sm">
    <p>© Flutter Developer, 2025</p>
    <p>Сделано с Flutter и любовью 🖤</p>
  </footer>
);
