# Flutter Portfolio

Личный сайт Flutter-разработчика.  
Собрано на React + Tailwind CSS.  
Готово к деплою на Vercel.

## Установка

```bash
npm install
npm run dev
